package jogoDasCoresSWING;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.LayoutManager;
import java.text.ParseException;

import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.text.MaskFormatter;

public class Teste {
   public static void main(String[] args) {
      createWindow();
   }

   private static void createWindow() {    
      JFrame frame = new JFrame("Swing Tester");
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      createUI(frame);
      frame.setSize(560, 200);      
      frame.setLocationRelativeTo(null);  
      frame.setVisible(true);
   }

   private static void createUI(final JFrame frame){  
      JPanel panel = new JPanel();
      LayoutManager layout = new FlowLayout();  
      panel.setLayout(layout);       

     JLabel zipLabel = new JLabel("Zip Code");
     JFormattedTextField zipTextField = null;
      try {
         zipTextField = new JFormattedTextField(
            new MaskFormatter("###.###.###-##")); 
         zipTextField.setColumns(20);
      } catch (ParseException e) {
         e.printStackTrace();
      }

      zipLabel.setLabelFor(zipTextField);
      
      panel.add(zipLabel);
      panel.add(zipTextField);

      frame.getContentPane().add(panel, BorderLayout.CENTER);    
   }  
}