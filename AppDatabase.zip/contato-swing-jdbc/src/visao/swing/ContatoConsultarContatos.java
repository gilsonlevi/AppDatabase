package visao.swing;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.JScrollPane;

public class ContatoConsultarContatos extends JFrame {

	private JPanel contentPane;
	private JTable tabela;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ContatoConsultarContatos frame = new ContatoConsultarContatos();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ContatoConsultarContatos() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 510, 215);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		
		String[] colunas = {"ID", "Nome", "Matricula"};
		Object[][] dados = {
				{1, "Felipe", 1234},
				{2, "Jo�o", 4321},
				{2, "Jo�o", 4321},
				{2, "Jo�o", 4321},
				{2, "Jo�o", 4321},
				{2, "Jo�o", 4321},
				{2, "Jo�o", 4321},
				{2, "Jo�o", 4321},
				{2, "Jo�o", 4321},
				{2, "Jo�o", 4321},
				{2, "Jo�o", 4321},
				{2, "Jo�o", 4321}
		};
		contentPane.setLayout(null);
		
		tabela = new JTable(dados, colunas);
		
		JScrollPane barraRolagem = new JScrollPane(tabela);
		barraRolagem.setBounds(10, 10, 476, 157);
		contentPane.add(barraRolagem);
	}

}
